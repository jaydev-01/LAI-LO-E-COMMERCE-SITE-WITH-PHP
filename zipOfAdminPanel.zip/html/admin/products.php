<?php
session_start();
if (empty($_SESSION['user'])) {
    header('location:/html/index.php');
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lai Lo | Products</title>
    <?php include_once "../components/head.php" ?>
</head>

<body>
    <div class="main-container">
        <div class="side-menu">
            <?php include_once "../components/sideMenu.php"; ?>
        </div>
        <div class="main-content-container">
            <?php include_once "../components/adminNavbar.php"; ?>
            <div class="row mx-5 mt-5 title">
                <h3>Products</h3>
            </div>
            <div class="row mx-5 my-3 title">
            <button type="button" class="btn btn-primary w-25" id="newProducts">NEW PRODUCTS</button>
            </div>
            <div class="main-page-content">
                <div class="table-card">
                    <table class="table table-hover" id="customerTable">
                        <table class="table table-hover" id="productTable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">PRODUCT IMAGE</th>
                                    <th scope="col">PRODUCT NAME</th>
                                    <th scope="col">PRICE</th>
                                    <th scope="col">CATEGORY</th>
                                    <th scope="col">AVAILABLE UNIT</th>
                                    <th scope="col">DESCRIPTION</th>
                                    <th scope="col">DISCOUNT</th>
                                    <th scope="col">ACTION</th>
                                </tr>
                            </thead>
                            <tbody id="productData">
                            </tbody>
                        </table>
                </div>
            </div>
        </div>
    </div>

    <script src="/js/ajax/products.js"></script>
    <?php include_once "../components/footer.php"; ?>

</body>

</html>