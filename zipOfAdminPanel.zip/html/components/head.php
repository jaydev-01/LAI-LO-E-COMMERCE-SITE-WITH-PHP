<!-- css link -->
<link rel="stylesheet" href="/css/lailo.css">
<link rel="stylesheet" href="/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/jquery.dataTables.min.css">

<!-- jquery -->
<script src="/js/jquery-3.6.0.min.js"></script>
<script src="/js/jquery.dataTables.min.js"></script>


<!-- link for icons -->
<script src="/assets/fontawesome_icons.js"></script>

<!-- icon of wensite -->
<link rel ="icon" href ="/images/icon.png" type = "image/x-icon">