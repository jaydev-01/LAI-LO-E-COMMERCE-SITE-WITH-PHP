<div class="sidebar">
    <div class="sidebar-brand">
        Admin Panel
    </div>

    <div class="sidebar-menu">
        <ul id="menu-option">
            <li><a href="dashboard.php"><i class="fa-solid fa-table-columns"></i>Dashboard</a></li>
            <li><a href="customers.php"><i class="fa-solid fa-users-rectangle"></i>Customers</a></li>
            <li><a href="products.php"><i class="fa-solid fa-shirt"></i>Products</a></li>
            <li><a href="orders.php"><i class="fa-solid fa-gavel"></i>Orders</a></li>
            <li><a href="categories.php"><i class="fa-solid fa-tape"></i>Categories</a></li>
            <li><a href="addProduct.php"><i class="fa-solid fa-cart-plus"></i>New Product</a></li>
            <li><a href="addCategory.php"><i class="fa-solid fa-circle-plus"></i>New Category</a></li>
            <li><a href="" onclick="logOut()"><i class="fa-solid fa-right-from-bracket"></i>Log Out</a></li>
        </ul>
    </div>
</div>