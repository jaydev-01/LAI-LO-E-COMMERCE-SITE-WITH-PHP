<div class="navbar-container" id="admin-navbar">
    <div class="menu-icon">
    <i class="fa-solid fa-bars"></i>
    </div>
    <div class="user-name" id="account-of-admin">
        <a href="#"><span>Jaydev  <i class="fa-solid fa-caret-down"></i></a>
        <div class="drop-down" id="dropDown">
            <li><a href=""><i class="fa-solid fa-user"></i> Profile</a></li>
            <li><a href="" onclick="logOut()"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a></li>
        </div>
    </div>
</div>